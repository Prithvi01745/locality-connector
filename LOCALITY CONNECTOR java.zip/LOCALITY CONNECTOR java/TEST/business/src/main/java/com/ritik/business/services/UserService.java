package com.ritik.business.services;

import com.ritik.business.models.User;
import com.ritik.business.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Method to validate user login
    public User loginUser(String username, String password) {
        return userRepository.findByUsernameAndPassword(username, password);
    }

    // Save the user to the database
    public void saveUser(User user) {
        userRepository.save(user);
    }

    // Check if the username exists
    public boolean emailExists(String email) {
        return userRepository.existsByEmail(email);
    }



    }




