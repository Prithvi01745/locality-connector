package com.ritik.business.controllers;

public class BusinessLocationRequest {
        private String businessName;
        private Double businessLatitude;
        private Double businessLongitude;

        // Getters and setters
        public String getBusinessName() {
            return businessName;
        }

        public void setBusinessName(String businessName) {
            this.businessName = businessName;
        }

        public Double getBusinessLatitude() {
            return businessLatitude;
        }

        public void setBusinessLatitude(Double businessLatitude) {
            this.businessLatitude = businessLatitude;
        }

        public Double getBusinessLongitude() {
            return businessLongitude;
        }

        public void setBusinessLongitude(Double businessLongitude) {
            this.businessLongitude = businessLongitude;
        }

}
