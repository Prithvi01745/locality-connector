//package com.ritik.business.services;
//
//import com.ritik.business.models.Business;
//import com.ritik.business.repository.BusinessRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Service
//public class BusinessService {
//
//    @Autowired
//    private BusinessRepository businessRepository;
//
//    // Method to save a new business in the database
//    public void saveBusiness(Business business) {
//        businessRepository.save(business);
//    }
//
//    // Method to check if email already exists
//    public boolean emailExists(String email) {
//        return businessRepository.existsByEmail(email);
//    }
//
//    // Method to validate business login
//    public Business loginBusiness(String businessName, String password) {
//        // Fetch the business from the database by businessName and password
//        return businessRepository.findByBusinessNameAndPassword(businessName, password);
//    }
//
//    public Business findByBusinessName(String businessName) {
//        return businessRepository.findByBusinessName(businessName);
//    }
//}

package com.ritik.business.services;

import com.ritik.business.models.Business;
import com.ritik.business.repository.BusinessRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BusinessService {

    @Autowired
    private BusinessRepository businessRepository;

    // Method to save a new business in the database
    @Transactional
    public void saveBusiness(Business business) {
        businessRepository.save(business);
    }

    // Method to check if email already exists
    @Transactional(readOnly = true)
    public boolean emailExists(String email) {
        return businessRepository.existsByEmail(email);
    }

    // Method to validate business login
    @Transactional(readOnly = true)
    public Business loginBusiness(String businessName, String password) {
        // Fetch the business from the database by businessName and password
        return businessRepository.findByBusinessNameAndPassword(businessName, password);
    }

    // Method to find a business by business name
    @Transactional(readOnly = true)
    public Business findByBusinessName(String businessName) {
        return businessRepository.findByBusinessName(businessName);
    }

    // **New Method:** Find a business by its ID
    @Transactional(readOnly = true)
    public Business findById(Long id) {
        return businessRepository.findById(id).orElse(null);
    }

    // Method to authenticate the business user
    public Business authenticate(String businessName, String password) {
        // Fetch the business by email
        Business business = businessRepository.findByBusinessName(businessName);

        // Check if the business exists and if the password matches
        if (business != null && business.getPassword().equals(password)) {
            return business;
        }
        return null; // Return null if authentication fails
    }

}
