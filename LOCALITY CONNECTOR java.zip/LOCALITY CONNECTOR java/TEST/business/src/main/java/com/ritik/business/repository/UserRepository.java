package com.ritik.business.repository;

import com.ritik.business.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    // Additional query methods can be defined here
    boolean existsByEmail(String email);

    User findByUsernameAndPassword(String username, String password);



}
