package com.ritik.business.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PageController {

    // Home Page
    @GetMapping("/")
    public String home() {
        return "index"; // Corresponds to home.html
    }

    // About Page
    @GetMapping("/about")
    public String about() {
        return "about"; // Corresponds to about.html
    }

    // Contact Page
    @GetMapping("/contact")
    public String contact() {
        return "contact"; // Corresponds to contact.html
    }

    // Login Page
    @GetMapping("/login")
    public String login() {
        return "login"; // Corresponds to login.html
    }

    // Signup Page
    @GetMapping("/signup")
    public String signup() {
        return "signup"; // Corresponds to signup.html
    }

    // User Home Page
    @GetMapping("/user_homepage")
    public String user_homepage() {
        return "user_homepage"; // Corresponds to user_homepage.html
    }

    // Remove this method to resolve the conflict
    // @GetMapping("/business_dashboard")
    // public String business_dashboard() {
    //     return "business_dashboard";  // Renders business_dashboard.html
    // }

    @GetMapping("/shop_details")
    public String shop_details() {
        return "shop_details"; // Corresponds to shop_details.html
    }

    @GetMapping("/update-business")
    public String showUpdateBusiness() {
        return "update-business"; // This corresponds to the Thymeleaf or HTML file in the templates folder
    }


    @GetMapping("/hospitalhomepage")
    public String showHospitalhomepage() {
        return "hospitalhomepage"; // This corresponds to the Thymeleaf or HTML file in the templates folder
    }


    @GetMapping("/listing")
    public String showListing() {
        return "listing"; // Thymeleaf will render listing.html
    }


    @GetMapping("/feedback")
    public String showFeedback() {
        return "feedback"; // Thymeleaf will render feedback.html
    }

    // Serve the Recommended Shops Page
    @GetMapping("/shop-details")
    public String showShopDetails() {
        return "shop-details"; // Renders src/main/resources/templates/shop-details.html
    }


    
    @GetMapping("/nearby_grocery")
    public String showNearbyGrocery() {
        return "nearby_grocery";
    }
    
    @GetMapping("/nearbyshops")
    public String showNearbyshops() {
        return "nearbyshops";



        }

    @GetMapping("/pharmacy")
    public String showPharmacy() {
        return "pharmacy";
    }



    @GetMapping("/fooditem")
    public String showFooditem() {
        return "fooditem";
    }


    @GetMapping("/stationary")
    public String showStationary() {
        return "stationary";
    }


    @GetMapping("/clothing")
    public String showClothing() {
        return "clothing";
    }

    @GetMapping("/nearbyfooditems")
    public String showNearbyfooditems() {
        return "nearbyfooditems";
    }

    @GetMapping("/nearbypharmacy")
    public String showNearbypharmacy() {
        return "nearbypharmacy";
    }


    @GetMapping("/nearbyclothing")
    public String showNearbyclothing() {
        return "nearbyclothing";
    }

    @GetMapping("/nearbyhardware")
    public String showNearbyhardware() {
        return "nearbyhardware";


    }


    @GetMapping("/orderplaced")
    public String showOrderplaced() {
        return "orderplaced";}

    @GetMapping("/order")
    public String showNorder() {
        return "order";}



    @GetMapping("/nearbyhospital")
    public String showNearbyhospital() {
        return "nearbyhospital"; // This corresponds to the Thymeleaf or HTML file in the templates folder
    }



    @GetMapping("/hospitals")
    public String showHospitals() {
        return "hospitals";}



    @GetMapping("/payment")
    public String showPayment() {
        return "payment";}


    @GetMapping("/bookappointment")
    public String showBookappointment() {
        return "bookappointment";}

    @GetMapping("/appointmentbooked")
    public String showAppointmentbooked() {
        return "appointmentbooked";}


    @GetMapping("/medicine")
    public String showMedicine() {
        return "medicine";}


    @GetMapping("/food")
    public String showFood() {
        return "food";}


    @GetMapping("/nearbystationary")
    public String showNearbystationary() {
        return "nearbystationary";}
    @GetMapping("/orders")
    public String showOrders() {
        return "nearbystationary";}

    @GetMapping("/details")
    public String showDetails() {
        return "details";}

    @GetMapping("/test")
    public String showTest() {
        return "test";}


}
