package com.ritik.business.services;

import com.ritik.business.models.Item;
import com.ritik.business.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ItemService {

    @Autowired
    private ItemRepository itemRepository;

    @Transactional
    public void saveItem(Item item) {
        itemRepository.save(item);
    }

    @Transactional(readOnly = true)
    public List<Item> getItemsByBusinessId(Long businessId) {
        return itemRepository.findByBusinessId(businessId);
    }

    // Additional methods like updateItem, deleteItem can be added here
}
