////package com.ritik.business.models;
////
////import jakarta.persistence.*;
////
////@Entity
////@Table(name = "businesses")
////public class Business {
////
////    @Id
////    @GeneratedValue(strategy = GenerationType.IDENTITY)
////    private Long id;
////
////    @Column(name = "business_name", nullable = false)
////    private String businessName;
////
////    @Column(name = "business_type", nullable = true)
////    private String businessType;
////
////    @Column(name = "business_description", nullable = true, columnDefinition = "TEXT")
////    private String businessDescription;
////
////    @Column(name = "business_address", nullable = false)
////    private String businessAddress;
////
////    @Column(name = "contact_number", nullable = true)
////    private String contactNumber;
////
////    @Column(name = "email", nullable = false, unique = true)
////    private String email;
////
////    @Column(name = "password", nullable = false)
////    private String password;
////
////    // Constructors
////    public Business() {}
////
////    public Business(String businessName, String businessType, String businessDescription,
////                    String businessAddress, String contactNumber, String email, String password) {
////        this.businessName = businessName;
////        this.businessType = businessType;
////        this.businessDescription = businessDescription;
////        this.businessAddress = businessAddress;
////        this.contactNumber = contactNumber;
////        this.email = email;
////        this.password = password;
////    }
////
////    // Getters and Setters
////    public Long getId() {
////        return id;
////    }
////
////    public void setId(Long id) {
////        this.id = id;
////    }
////
////    public String getBusinessName() {
////        return businessName;
////    }
////
////    public void setBusinessName(String businessName) {
////        this.businessName = businessName;
////    }
////
////    public String getBusinessType() {
////        return businessType;
////    }
////
////    public void setBusinessType(String businessType) {
////        this.businessType = businessType;
////    }
////
////    public String getBusinessDescription() {
////        return businessDescription;
////    }
////
////    public void setBusinessDescription(String businessDescription) {
////        this.businessDescription = businessDescription;
////    }
////
////    public String getBusinessAddress() {
////        return businessAddress;
////    }
////
////    public void setBusinessAddress(String businessAddress) {
////        this.businessAddress = businessAddress;
////    }
////
////    public String getContactNumber() {
////        return contactNumber;
////    }
////
////    public void setContactNumber(String contactNumber) {
////        this.contactNumber = contactNumber;
////    }
////
////    public String getEmail() {
////        return email;
////    }
////
////    public void setEmail(String email) {
////        this.email = email;
////    }
////
////    public String getPassword() {
////        return password;
////    }
////
////    public void setPassword(String password) {
////        this.password = password;
////    }
////}
//
//package com.ritik.business.models;
//
//import jakarta.persistence.*;
//
//import java.math.BigDecimal;
//import java.util.Set;
//
//@Entity
//@Table(name = "businesses")
//public class Business {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @Column(name = "business_name", nullable = false, unique = true)
//    private String businessName;
//
//    @Column(name = "business_type", nullable = true)
//    private String businessType;
//
//    @Column(name = "business_description", nullable = true, columnDefinition = "TEXT")
//    private String businessDescription;
//
//    @Column(name = "business_address", nullable = false)
//    private String businessAddress;
//
//    @Column(name = "contact_number", nullable = true)
//    private String contactNumber;
//
//    @Column(name = "email", nullable = false, unique = true)
//    private String email;
//
//    @Column(name = "password", nullable = false)
//    private String password;
//
//
//    @Column(name = "longitude", precision = 11, scale = 8, nullable = true)
//    private BigDecimal longitude;
//
//    @Column(name = "latitude", precision = 10, scale = 8, nullable = true)
//    private BigDecimal latitude;
//
//
//    // Relationships
//
//    @OneToMany(mappedBy = "business", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    private Set<Item> items;
////
////    @OneToMany(mappedBy = "business", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
////    private Set<Order> orders;
////
////    @OneToMany(mappedBy = "business", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
////    private Set<Feedback> feedbacks;
//
//    // Constructors
//
//    public Business() {}
//
//    public Business(String businessName, String businessType, String businessDescription,
//                    String businessAddress, String contactNumber, String email, String password,
//                    Double longitude, Double latitude) {
//        this.businessName = businessName;
//        this.businessType = businessType;
//        this.businessDescription = businessDescription;
//        this.businessAddress = businessAddress;
//        this.contactNumber = contactNumber;
//        this.email = email;
//        this.password = password;
//        this.longitude = null;
//        this.latitude = null;
//    }
//
//    // Getters and Setters
//
//    // ID
//    public Long getId() {
//        return id;
//    }
//
//    // Business Name
//    public String getBusinessName() {
//        return businessName;
//    }
//
//    public void setBusinessName(String businessName) {
//        this.businessName = businessName;
//    }
//
//    // Business Type
//    public String getBusinessType() {
//        return businessType;
//    }
//
//    public void setBusinessType(String businessType) {
//        this.businessType = businessType;
//    }
//
//    // Business Description
//    public String getBusinessDescription() {
//        return businessDescription;
//    }
//
//    public void setBusinessDescription(String businessDescription) {
//        this.businessDescription = businessDescription;
//    }
//
//    // Business Address
//    public String getBusinessAddress() {
//        return businessAddress;
//    }
//
//    public void setBusinessAddress(String businessAddress) {
//        this.businessAddress = businessAddress;
//    }
//
//    // Contact Number
//    public String getContactNumber() {
//        return contactNumber;
//    }
//
//    public void setContactNumber(String contactNumber) {
//        this.contactNumber = contactNumber;
//    }
//
//    // Email
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    // Password
//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }
//
//    // Longitude
//    public Double getLongitude() {
//        return longitude;
//    }
//
//    public void setLongitude(Double longitude) {
//        this.longitude = longitude;
//    }
//
//    // Latitude
//    public Double getLatitude() {
//        return latitude;
//    }
//
//    public void setLatitude(Double latitude) {
//        this.latitude = latitude;
//    }
//
//    // Items
//    public Set<Item> getItems() {
//        return items;
//    }
//
//    public void setItems(Set<Item> items) {
//        this.items = items;
//    }
////
////    // Orders
////    public Set<Order> getOrders() {
////        return orders;
////    }
////
////    public void setOrders(Set<Order> orders) {
////        this.orders = orders;
////    }
////
////    // Feedbacks
////    public Set<Feedback> getFeedbacks() {
////        return feedbacks;
////    }
////
////    public void setFeedbacks(Set<Feedback> feedbacks) {
////        this.feedbacks = feedbacks;
////    }
//
//    // equals and hashCode based on id
//
//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//
//        Business business = (Business) o;
//
//        return id != null ? id.equals(business.id) : business.id == null;
//    }
//
//    @Override
//    public int hashCode() {
//        return id != null ? id.hashCode() : 0;
//    }
//
//    // toString
//
//    @Override
//    public String toString() {
//        return "Business{" +
//                "id=" + id +
//                ", businessName='" + businessName + '\'' +
//                ", businessType='" + businessType + '\'' +
//                ", businessDescription='" + businessDescription + '\'' +
//                ", businessAddress='" + businessAddress + '\'' +
//                ", contactNumber='" + contactNumber + '\'' +
//                ", email='" + email + '\'' +
//                ", longitude=" + longitude +
//                ", latitude=" + latitude +
//                '}';
//    }
//}
//







package com.ritik.business.models;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "businesses")
public class Business {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "business_name", nullable = false, unique = true)
    private String businessName;

    @Column(name = "business_type", nullable = true)
    private String businessType;

    @Column(name = "business_description", nullable = true, columnDefinition = "TEXT")
    private String businessDescription;

    @Column(name = "business_address", nullable = false)
    private String businessAddress;

    @Column(name = "contact_number", nullable = true)
    private String contactNumber;

    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "longitude", precision = 11, scale = 8, nullable = false)
    private BigDecimal longitude;

    @Column(name = "latitude", precision = 10, scale = 8, nullable = false)
    private BigDecimal latitude;

    // No-Argument Constructor
    public Business() {}

    // 7-Argument Constructor
    public Business(String businessName, String businessType, String businessDescription,
                    String businessAddress, String contactNumber, String email, String password) {
        this.businessName = businessName;
        this.businessType = businessType;
        this.businessDescription = businessDescription;
        this.businessAddress = businessAddress;
        this.contactNumber = contactNumber;
        this.email = email;
        this.password = password;
        this.longitude = null;
        this.latitude = null;
    }

    // 9-Argument Constructor
    public Business(String businessName, String businessType, String businessDescription,
                    String businessAddress, String contactNumber, String email, String password,
                    BigDecimal longitude, BigDecimal latitude) {
        this.businessName = businessName;
        this.businessType = businessType;
        this.businessDescription = businessDescription;
        this.businessAddress = businessAddress;
        this.contactNumber = contactNumber;
        this.email = email;
        this.password = password;
        this.longitude = longitude;
        this.latitude = latitude;
    }

    // Getters and Setters
    // ... (Ensure all fields have corresponding getters and setters)

    public Long getId() {
        return id;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public String getBusinessDescription() {
        return businessDescription;
    }

    public void setBusinessDescription(String businessDescription) {
        this.businessDescription = businessDescription;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }
}
