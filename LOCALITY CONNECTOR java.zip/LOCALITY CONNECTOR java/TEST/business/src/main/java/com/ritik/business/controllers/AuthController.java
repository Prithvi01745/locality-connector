package com.ritik.business.controllers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ritik.business.models.*;
import com.ritik.business.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.ritik.business.repository.BusinessRepository;
import com.ritik.business.services.BusinessService;
import com.ritik.business.services.ItemService;
import com.ritik.business.services.UserService;

import jakarta.servlet.http.HttpSession;


@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private BusinessService businessService;

    @Autowired
    private BusinessRepository businessRepository;

    @Autowired
    private ItemService itemService;
    private Double longitude;

    @PostMapping("/signup")
    public String processSignup(@RequestParam("username") String username,
                                @RequestParam("email") String email,
                                @RequestParam("password") String password,
                                @RequestParam("address") String address,
                                Model model) {

        // Check if the email already exists
        if (userService.emailExists(email)) {
            model.addAttribute("error", "Email is already registered");
            return "signup";  // Return to signup page with error message
        }

        // Create and save the new user
        User newUser = new User(username, email, password, address);  // Use 'username' here
        userService.saveUser(newUser);

        // Redirect to login or another page after successful signup
        return "redirect:/login";
    }


    @PostMapping("/business-signup")
    public String processBusinessSignup(@RequestParam("business-name") String businessName,
                                        @RequestParam(value = "business_type", required = false) String business_type,
                                        @RequestParam(value = "business-description", required = false) String businessDescription,
                                        @RequestParam("business_address") String businessAddress,
                                        @RequestParam(value = "contact-number", required = false) String contactNumber,
                                        @RequestParam("email") String email,
                                        @RequestParam("password") String password,
                                        @RequestParam(value = "longitude", required = false) Double longitude,
                                        @RequestParam(value = "latitude", required = false) Double latitude,
                                        Model model) {
        this.longitude = longitude;
        // Check if the email already exists
        if (businessService.emailExists(email)) {
            model.addAttribute("error", "Email is already registered");
            return "signup";  // Return to signup page with error message
        }
//        // Validate latitude and longitude (set default values if null)
        if (latitude == null) {
            latitude = 0.0;  // Default latitude (e.g., center of a region or a generic coordinate)
        }
        if (longitude == null) {
            longitude = 0.0;  // Default longitude
        }

        // Create and save the new business
        Business newBusiness = new Business(businessName, business_type, businessDescription, businessAddress, contactNumber, email, password, null, null);
        businessService.saveBusiness(newBusiness);

        // Redirect to login or another page after successful signup
        return "redirect:/business_dashboard";
    }


    @GetMapping("/business_dashboard")
    public String businessDashboard() {
        return "business_dashboard";  // Render business_dashboard.html
    }

    @PostMapping("/login")
    public String processLogin(
            @RequestParam("category") String category,  // This determines if it's user or business
            @RequestParam("password") String password,
            @RequestParam(required = false) String username,  // Username is optional
            @RequestParam(value = "business_name", required = false) String businessName,
            HttpSession session,// BusinessName is optional
            Model model) {

        if (category.equals("user")) {
            // Attempt user login
            if (username != null) {
                User user = userService.loginUser(username, password);
                if (user != null) {
                    return "redirect:/user_homepage"; // Redirect to user's homepage
                }
                model.addAttribute("error", "Invalid username or password");
                return "login"; // Return to login page
            }
        } else if (category.equals("business")) {
            // Attempt business login
            if (businessName != null) {
                Business business = businessService.loginBusiness(businessName, password);
//                Business business1 = businessService.authenticate(businessName, password);
                if (business != null) {
//                    session.setAttribute("loggedInBusinessName", business.getBusinessName());
                    session.setAttribute("loggedInBusinessName", business.getBusinessName());
                    System.out.println("Logged in business name: " + business.getBusinessName()); // Debugging line
                    return "redirect:/update-business"; // Redirect to business dashboard
                }
                model.addAttribute("error", "Invalid businessName or password");
                return "login"; // Return to login page
            }
        }
        // If neither username nor businessName are provided or if category is missing
        model.addAttribute("error", "Please provide valid credentials");
        return "login";
    }





    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate(); // Invalidate the session
        return "redirect:/login";
    }

    @PostMapping("/update-business")
    public String updateBusiness(
            @RequestParam("business_name") String businessName,
            @RequestParam("business_type") String businessType,
            @RequestParam("business_description") String businessDescription,
            @RequestParam("business_address") String businessAddress,
            @RequestParam("contact_number") String contactNumber,
            Model model) {

        // Find the business by business name
        Business existingBusiness = businessService.findByBusinessName(businessName);

        // If the business exists, update its details
        if (existingBusiness != null) {
            existingBusiness.setBusinessType(businessType);
            existingBusiness.setBusinessDescription(businessDescription);
            existingBusiness.setBusinessAddress(businessAddress);
            existingBusiness.setContactNumber(contactNumber);

            // Save the updated business details
            businessService.saveBusiness(existingBusiness);

            // Redirect to the business dashboard
            return "redirect:/update-business";
        } else {
            model.addAttribute("error", "Business not found");
            return "error"; // Return an error page if the business doesn't exist
        }
    }


    @PostMapping("/business_dashboard")
    public String saveBusinessDetails(@ModelAttribute Business business, Model model) {
        // Save business details to the database
        businessRepository.save(business);
        model.addAttribute("message", "Business details saved successfully!");
        return "business_dashboard";
    }


    @PostMapping("/saveItem")
    public String saveItem(
            @RequestParam("businessId") Long businessId,
            @RequestParam("itemName") String itemName,
            @RequestParam("itemPrice") Double itemPrice,
            @RequestParam("itemDescription") String itemDescription,
            Model model) {

        // Find the business by ID
        Business business = businessService.findById(businessId);
        if (business != null) {
            // Create new Item
            Item item = new Item();
            item.setBusiness(business);
            item.setItemName(itemName);
            item.setItemPrice(itemPrice);
            item.setItemDescription(itemDescription);
            itemService.saveItem(item);

            // Redirect to business dashboard or item list
            return "redirect:/business_homepage";
        } else {
            model.addAttribute("error", "Business not found");
            return "error"; // Ensure you have an error.html template
        }
    }


    @PostMapping("/saveLocation")
    public String saveLocation(@RequestBody BusinessLocationRequest request, HttpSession session,Model model) {
        String businessName = request.getBusinessName();
        Double latitude = request.getBusinessLatitude();
        Double longitude = request.getBusinessLongitude();

        // Log the incoming data (use a logger in production)
        System.out.println("Saving location for business: " + businessName);
        System.out.println("Latitude: " + latitude + ", Longitude: " + longitude);


        String loggedbusinessName = (String) session.getAttribute("loggedInBusinessName");
        System.out.println("business: " + loggedbusinessName);
        // Find the business by name
        Business business = businessService.findByBusinessName(loggedbusinessName);
        if (business != null) {
            // Convert latitude and longitude from Double to BigDecimal
            BigDecimal latitudeBigDecimal = BigDecimal.valueOf(latitude).setScale(6, RoundingMode.HALF_UP);
            BigDecimal longitudeBigDecimal = BigDecimal.valueOf(longitude).setScale(6, RoundingMode.HALF_UP);

            // Update latitude and longitude
            business.setLatitude(latitudeBigDecimal);
            business.setLongitude(longitudeBigDecimal);

            // Save the updated business
            businessService.saveBusiness(business);

            // Redirect to business homepage or dashboard
            return "redirect:/business_homepage";
        } else {
            model.addAttribute("error", "Business not found");
            return "error"; // Ensure you have an error.html template
        }
    }


    @GetMapping("/business_homepage")
    public String showBusinessHomepage() {
        return "business_homepage"; // Ensure this HTML file exists in src/main/resources/templates/
    }

    @PostMapping("/shop-details")
    public String showShopDetails() {
        return "shop-details";
    }

    @PostMapping("/nearby_grocery")
        public ResponseEntity<Map<String, Object>> findNearbyShops(@RequestBody LocationRequest request) {
        BigDecimal userLatitude = request.getLatitude();
        System.out.println("userLatitude: " + userLatitude);
        BigDecimal userLongitude = request.getLongitude();
        System.out.println("userLongitude: " + userLongitude);


            // Retrieve all shops from the database
            List<Business> allShops = businessRepository.findAll();
            List<Business> nearbyShops = new ArrayList<>();

            // Haversine formula to calculate distance
            for (Business shop : allShops) {
                double distance = calculateDistance(userLatitude, userLongitude, shop.getLatitude(), shop.getLongitude());
                if (distance <= 5.0) {  // 5km radius
                    nearbyShops.add(shop);
                }
            }

            Map<String, Object> response = new HashMap<>();
            response.put("shops", nearbyShops);

            return ResponseEntity.ok(response);
        }

        // Haversine formula to calculate distance between two lat/lng points in km
        public double calculateDistance(BigDecimal lat1, BigDecimal lon1, BigDecimal lat2, BigDecimal lon2) {
            final int R = 6371; // Radius of the earth in km
            double latDistance = Math.toRadians(lat2.doubleValue() - lat1.doubleValue());
            double lonDistance = Math.toRadians(lon2.doubleValue() - lon1.doubleValue());
            double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                    + Math.cos(Math.toRadians(lat1.doubleValue())) * Math.cos(Math.toRadians(lat2.doubleValue()))
                    * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            double distance = R * c; // convert to kilometers

            return distance;
        }


    @PostMapping("/grocery-list")
    public String ShowGroceryList() {
        return "grocery-list";
    }

    @PostMapping("/nearbypharmacy")
    public String showNearbypharmacy() {
        return "nearbypharmacy"; // Ensure this HTML file exists in src/main/resources/templates/
    }

    @PostMapping("/nearbyfooditems")
    public String showNearbyfooditems() {
        return "nearbyfooditems";}


    @PostMapping("/stationary")
    public String showStationary() {
        return "stationary";}


    @PostMapping("/nearbyclothing")
    public String showNearbyclothing() {
        return "nearbyclothing";}


    @RestController
    @RequestMapping("/inventory")
    public class InventoryController {

        @Autowired
        private InventoryRepository inventoryRepository;

        // Add Inventory Item
        @PostMapping("/add")
        public ResponseEntity<String> addItem(@RequestBody InventoryItem item) {
            try {
                inventoryRepository.save(item);
                return ResponseEntity.ok("Item added successfully!");
            } catch (Exception e) {
                return ResponseEntity.badRequest().body("Error adding item.");
            }
        }

        // Get All Inventory Items
        @GetMapping("/list")
        public List<InventoryItem> getAllItems() {
            return inventoryRepository.findAll();
        }
    }



    @PostMapping("/orderplaced")
    public String showOrderplaced() {
        return "orderplaced";}

    @PostMapping("/order")
    public String showOrder() {
        return "order";}


    @PostMapping("/hospitalhomepage")
    public String showHospitalhomepage() {
        return "hospitalhomepage";}


    @PostMapping("/nearbyhospital")
    public String showNearbyhospital() {
        return "nearbyhospital";}


    @PostMapping("/bookappointment")
    public String showBookappointment() {
        return "bookappointment";}


    @PostMapping("/appointmentbooked")
    public String showAppointmentbooked() {
        return "appointmentbooked";}


    @PostMapping("/hospitals")
    public String showHospitals() {
        return "hospitals";}


    @PostMapping("/payment")
    public String showPayment() {
        return "payment";}


    @PostMapping("/medicine")
    public String showMedicine() {
        return "medicine";}


    @PostMapping("/food")
    public String showFood() {
        return "food";}

    @PostMapping("/nearbystationary")
    public String showNearbystationary() {
        return "nearbystationary";}


    @PostMapping("/orders")
    public String showOrders() {
        return "orders";}

    @PostMapping("/details")
    public String showDetails() {
        return "details";}

    @PostMapping("/test")
    public String showTest() {
        return "test";}

}





