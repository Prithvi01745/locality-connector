//package com.ritik.business.repository;
//
//import com.ritik.business.models.Business;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface BusinessRepository extends JpaRepository<Business, Long> {
//    boolean existsByEmail(String email);
//
//    Business findByBusinessNameAndPassword(String businessName, String password);
//
//    Business findByBusinessName(String businessName);
//}

package com.ritik.business.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ritik.business.models.Business;

@Repository
public interface BusinessRepository extends JpaRepository<Business, Long> {
    // Custom query methods
    Business findByBusinessName(String businessName);
    Business findByEmail(String email);
    Business findByBusinessNameAndPassword(String businessName, String password);
    boolean existsByEmail(String email);

    
    @Query(value = "SELECT * FROM business b WHERE " +
            "(6371 * acos(cos(radians(:latitude)) * cos(radians(b.latitude)) * " +
            "cos(radians(b.longitude) - radians(:longitude)) + " +
            "sin(radians(:latitude)) * sin(radians(b.latitude)))) < :radius",
            nativeQuery = true)
    List<Business> findShopsWithinRadius(
            @Param("latitude") Double latitude,
            @Param("longitude") Double longitude,
            @Param("radius") Double radius);

}
